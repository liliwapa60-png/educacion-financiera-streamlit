"""
db.py — Conexión a Supabase (Postgres). Usa la MISMA base de datos que ya
está conectada al backend de la versión web, así que una cuenta creada
aquí, o en la web, es la misma cuenta (comparten usuarios y datos).

Requiere la librería psycopg2-binary (ver requirements.txt) y la variable
de entorno / secreto de Streamlit DATABASE_URL con la cadena de conexión
de Supabase.
"""
import hashlib
import secrets
import psycopg2
import psycopg2.extras
import streamlit as st

PBKDF2_ITERATIONS = 200_000


def get_connection():
    """Una conexión nueva por llamada — Streamlit vuelve a correr el script
    en cada interacción, así que no conviene mantener una conexión abierta
    entre ejecuciones."""
    database_url = st.secrets["DATABASE_URL"]
    return psycopg2.connect(database_url, sslmode="require")


def init_db():
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    name TEXT NOT NULL,
                    country TEXT NOT NULL,
                    method TEXT NOT NULL,
                    contact TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL DEFAULT '',
                    salt TEXT NOT NULL DEFAULT '',
                    push_subscription JSONB,
                    data JSONB NOT NULL DEFAULT '{}'::jsonb,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    token TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
                );
            """)
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------
# Contraseñas — mismo método que la versión de escritorio y la web:
# PBKDF2-HMAC-SHA256, 200,000 iteraciones, sal aleatoria por cuenta.
# ---------------------------------------------------------------
def hash_password(password, salt_hex=None):
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return digest.hex(), salt.hex()


def verify_password(password, password_hash_hex, salt_hex):
    if not password_hash_hex or not salt_hex:
        return False
    computed, _ = hash_password(password, salt_hex)
    return secrets.compare_digest(computed, password_hash_hex)


def is_strong_enough(password):
    return len(password) >= 6


def _row_to_user(row):
    return {"id": row["id"], "name": row["name"], "country": row["country"],
            "method": row["method"], "contact": row["contact"]}


# ---------------------------------------------------------------
# Cuentas
# ---------------------------------------------------------------
def contact_exists(contact):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM users WHERE contact = %s", (contact,))
            return cur.fetchone() is not None
    finally:
        conn.close()


def create_user(name, country, method, contact, password):
    password_hash, salt = hash_password(password)
    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                """INSERT INTO users (name, country, method, contact, password_hash, salt)
                   VALUES (%s, %s, %s, %s, %s, %s)
                   RETURNING id, name, country, method, contact""",
                (name, country, method, contact, password_hash, salt),
            )
            row = cur.fetchone()
        conn.commit()
        return _row_to_user(row)
    finally:
        conn.close()


def authenticate(contact, password):
    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("SELECT * FROM users WHERE contact = %s", (contact,))
            row = cur.fetchone()
        if not row or not verify_password(password, row["password_hash"], row["salt"]):
            return None
        return _row_to_user(row)
    finally:
        conn.close()


def get_user_by_id(user_id):
    conn = get_connection()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "SELECT id, name, country, method, contact FROM users WHERE id = %s", (user_id,)
            )
            row = cur.fetchone()
        return _row_to_user(row) if row else None
    finally:
        conn.close()


def update_password(user_id, new_password):
    password_hash, salt = hash_password(new_password)
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE users SET password_hash = %s, salt = %s WHERE id = %s",
                (password_hash, salt, user_id),
            )
        conn.commit()
    finally:
        conn.close()


def delete_user(user_id):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------
# Datos financieros (gastos, deudas, metas, recordatorios, etc.)
# ---------------------------------------------------------------
def load_user_data(user_id):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT data FROM users WHERE id = %s", (user_id,))
            row = cur.fetchone()
        return row[0] if row else None
    finally:
        conn.close()


def save_user_data(user_id, data_dict):
    import json
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE users SET data = %s WHERE id = %s",
                (json.dumps(data_dict), user_id),
            )
        conn.commit()
    finally:
        conn.close()
