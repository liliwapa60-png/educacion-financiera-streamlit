"""
logic.py — Toda la lógica de negocio de la app, sin nada de interfaz gráfica.

Se separa así a propósito: esto se puede probar con un simple `python3 -c`
o un test, sin necesitar pantalla ni Tkinter corriendo.
"""
import json
import math
import os
import sys


def _resource_dir(*parts):
    """Encuentra una carpeta junto al programa — funciona tanto corriendo
    como script normal (python3 main.py) como empaquetada con PyInstaller
    (donde los archivos se extraen a una carpeta temporal distinta,
    guardada en sys._MEIPASS)."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


DATA_DIR = _resource_dir("data")


def _load(filename):
    with open(os.path.join(DATA_DIR, filename), encoding="utf-8") as f:
        return json.load(f)


COUNTRY_CURRENCY = _load("country_currency.json")
COUNTRY_PHONE = _load("country_phone.json")
TAX_BRACKETS_RAW = _load("tax_brackets.json")

COURSE_DATA = {
    "personal": {"title": "Finanzas Personales", "data": _load("course_personal.json")},
    "empresarial": {"title": "Finanzas Empresariales", "data": _load("course_empresarial.json")},
    "publicas": {"title": "Finanzas Públicas", "data": _load("course_publicas.json")},
    "economia": {"title": "Economía", "data": _load("course_economia.json")},
    "todos": {"title": "Educación Financiera para Todos", "data": _load("course_todos.json")},
}

COUNTRIES = list(COUNTRY_CURRENCY.keys())

# Símbolo/formato de moneda por código ISO — suficiente para mostrar montos
# de forma clara sin depender del locale del sistema operativo (poco confiable
# entre Windows/Mac/Linux).
CURRENCY_SYMBOLS = {
    "HNL": "L", "MXN": "$", "GTQ": "Q", "USD": "$", "NIO": "C$",
    "CRC": "₡", "PEN": "S/", "CLP": "$",
}


def format_money(amount, country):
    info = COUNTRY_CURRENCY.get(country, COUNTRY_CURRENCY["Honduras"])
    currency = info["currency"]
    symbol = CURRENCY_SYMBOLS.get(currency, currency + " ")
    sign = "-" if amount < 0 else ""
    amount = abs(amount)
    # separador de miles con coma, sin decimales (igual que la app original)
    formatted = f"{amount:,.0f}"
    return f"{sign}{symbol}{formatted}"


# ---------------------------------------------------------------
# Impuesto progresivo por tramos (motor genérico) — igual lógica
# que en la app web: cada tramo paga solo su propia tasa (marginal).
# ---------------------------------------------------------------
def _brackets_from_raw(key):
    raw = TAX_BRACKETS_RAW[key]
    return [(b["upTo"] if b["upTo"] is not None else math.inf, b["rate"]) for b in raw]


def compute_progressive_tax(base, brackets):
    tax = 0.0
    lower = 0.0
    for up_to, rate in brackets:
        if base <= lower:
            break
        taxable_in_bracket = min(base, up_to) - lower
        tax += taxable_in_bracket * rate
        lower = up_to
    return tax


HN_BRACKETS = _brackets_from_raw("HN")
MX_BRACKETS = _brackets_from_raw("MX")
PE_BRACKETS = _brackets_from_raw("PE")
CL_BRACKETS = _brackets_from_raw("CL")
GT_BRACKETS = _brackets_from_raw("GT")
SV_BRACKETS = _brackets_from_raw("SV")
NI_BRACKETS = _brackets_from_raw("NI")
PA_BRACKETS = _brackets_from_raw("PA")
CR_BRACKETS = _brackets_from_raw("CR")
PE_UIT_2025 = TAX_BRACKETS_RAW["PE_UIT_2025"]
CL_UTM_2025 = TAX_BRACKETS_RAW["CL_UTM_2025"]


def compute_honduras_isr(monthly_salary):
    return compute_progressive_tax(monthly_salary, HN_BRACKETS)


def compute_mexico_isr(monthly_salary):
    return compute_progressive_tax(monthly_salary, MX_BRACKETS)


def compute_peru_ir(monthly_salary):
    annual_gross = monthly_salary * 12
    taxable_annual = max(0.0, annual_gross - 7 * PE_UIT_2025)
    annual_tax = compute_progressive_tax(taxable_annual, PE_BRACKETS)
    return annual_tax / 12


def compute_chile_iusc(monthly_salary):
    renta_liquida_imponible = monthly_salary * 0.824
    return compute_progressive_tax(renta_liquida_imponible, CL_BRACKETS)


def compute_guatemala_isr(monthly_salary):
    annual_gross = monthly_salary * 12
    igss = annual_gross * 0.0483
    taxable_annual = max(0.0, annual_gross - 48000 - igss)
    return compute_progressive_tax(taxable_annual, GT_BRACKETS) / 12


def compute_el_salvador_isr(monthly_salary):
    return compute_progressive_tax(monthly_salary, SV_BRACKETS)


def compute_nicaragua_ir(monthly_salary):
    annual_net_of_inss = monthly_salary * (1 - 0.07) * 12
    return compute_progressive_tax(annual_net_of_inss, NI_BRACKETS) / 12


def compute_panama_isr(monthly_salary):
    annual_gross = monthly_salary * 12
    return compute_progressive_tax(annual_gross, PA_BRACKETS) / 12


def compute_costa_rica_tax(monthly_salary):
    return compute_progressive_tax(monthly_salary, CR_BRACKETS)


PROGRESSIVE_TAX_CALC = {
    "Honduras": compute_honduras_isr,
    "México": compute_mexico_isr,
    "Perú": compute_peru_ir,
    "Chile": compute_chile_iusc,
    "Guatemala": compute_guatemala_isr,
    "El Salvador": compute_el_salvador_isr,
    "Nicaragua": compute_nicaragua_ir,
    "Panamá": compute_panama_isr,
    "Costa Rica": compute_costa_rica_tax,
}

TAX_HINTS = {
    "Honduras": "Tabla progresiva real del ISR (SAR, 2025): exento hasta L21,457.76/mes, 15% hasta L30,969.86, 20% hasta L67,604.36, y 25% en adelante.",
    "México": "Tarifa mensual real del ISR (Art. 96 LISR, SAT 2025), 11 tramos del 1.92% al 35%.",
    "Perú": "Impuesto a la Renta de 5ta categoría (Sunat 2025): se resta la deducción de 7 UIT al año y se aplican tramos del 8% al 30%.",
    "Chile": "Impuesto Único de Segunda Categoría (SII), sobre la renta líquida imponible (bruto menos AFP/salud/cesantía, aprox. 17.6%).",
    "Guatemala": "ISR de rentas del trabajo (SAT, Decreto 10-2012): deducción de Q48,000 + IGSS (4.83%), tramos de 5% y 7%.",
    "El Salvador": "Tabla de retención del ISR (Ministerio de Hacienda, reforma mayo 2025): exento hasta $550/mes, tramos de 10%, 20% y 30%.",
    "Nicaragua": "IR laboral (Ley 822), sobre el ingreso neto del 7% de INSS laboral, tramos anuales del 15% al 30%.",
    "Panamá": "ISR para personas naturales (DGI-MEF): exento hasta $11,000/año, 15% hasta $50,000, 25% en adelante.",
    "Costa Rica": "Impuesto al Salario (Ministerio de Hacienda): exento hasta ₡918,000/mes, tramos de 10%, 15%, 20% y 25%.",
}


def compute_salary_tax(country, monthly_gross):
    """Devuelve (impuesto, tasa_efectiva, es_calculo_real)."""
    calc = PROGRESSIVE_TAX_CALC.get(country)
    if calc:
        tax = calc(monthly_gross)
        rate = tax / monthly_gross if monthly_gross > 0 else 0
        return tax, rate, True
    # Ningún país fuera de los 9 debería llegar aquí (el login los limita),
    # pero por seguridad usamos una tasa aproximada del 15%.
    tax = monthly_gross * 0.15
    return tax, 0.15, False


# ---------------------------------------------------------------
# Interés compuesto / simple, préstamos, retiro — mismas fórmulas
# que la calculadora web.
# ---------------------------------------------------------------
def compute_interest(mode, principal, monthly_contribution, annual_rate_pct, years):
    r = annual_rate_pct / 100
    if mode == "simple":
        total = principal * (1 + r * years)
        invested = principal
    else:
        monthly_rate = r / 12
        n = years * 12
        fv_principal = principal * ((1 + monthly_rate) ** n)
        if monthly_rate > 0:
            fv_contrib = monthly_contribution * (((1 + monthly_rate) ** n - 1) / monthly_rate)
        else:
            fv_contrib = monthly_contribution * n
        total = fv_principal + fv_contrib
        invested = principal + monthly_contribution * n
    return total, invested, total - invested


def compute_loan(amount, annual_rate_pct, years):
    annual_rate = annual_rate_pct / 100
    n = years * 12
    monthly_rate = annual_rate / 12
    if amount <= 0 or n <= 0:
        return 0.0, 0.0, 0.0
    if monthly_rate > 0:
        payment = (amount * monthly_rate) / (1 - (1 + monthly_rate) ** (-n))
    else:
        payment = amount / n
    total_paid = payment * n
    return payment, total_paid, total_paid - amount


def compute_retirement(current_age, retire_age, current_savings, monthly_contribution, annual_rate_pct):
    years = max(0, retire_age - current_age)
    annual_rate = annual_rate_pct / 100
    monthly_rate = annual_rate / 12
    n = years * 12
    fv_savings = current_savings * ((1 + monthly_rate) ** n)
    if monthly_rate > 0:
        fv_contrib = monthly_contribution * (((1 + monthly_rate) ** n - 1) / monthly_rate)
    else:
        fv_contrib = monthly_contribution * n
    total = fv_savings + fv_contrib
    total_contributed = current_savings + monthly_contribution * n
    monthly_at_4pct = (total * 0.04) / 12
    return total, total_contributed, total - total_contributed, monthly_at_4pct, years


# ---------------------------------------------------------------
# Validación de correo / teléfono (igual que la app web)
# ---------------------------------------------------------------
import re as _re

_EMAIL_RE = _re.compile(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?"
    r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,24}$"
)


def is_valid_email(email):
    return bool(_EMAIL_RE.match(email.strip()))


def is_obviously_fake_phone(digits):
    if _re.match(r"^(\d)\1+$", digits):
        return True
    ascending = "0123456789"
    descending = "9876543210"
    return digits in ascending or digits in descending


def is_valid_phone(country, digits):
    info = COUNTRY_PHONE.get(country, COUNTRY_PHONE["Honduras"])
    return len(digits) == info["digits"] and not is_obviously_fake_phone(digits)


# ---------------------------------------------------------------
# Indemnización por despido sin causa justificada — fórmulas reales
# de cada país. Son estimaciones simplificadas con fines educativos:
# los sistemas reales tienen excepciones, topes salariales y otros
# rubros (aguinaldo/vacaciones proporcionales) que aquí no se incluyen
# en su totalidad. NO sustituye asesoría legal laboral.
# Solo aplica a despido SIN causa justificada — una renuncia o un
# despido con causa justificada no generan este pago (o generan uno
# distinto y menor).
# ---------------------------------------------------------------
def severance_honduras(monthly_salary, years):
    if years < 0.25:
        preaviso_months = 0.03  # 24 horas, aprox.
    elif years < 0.5:
        preaviso_months = 0.25  # 1 semana
    elif years < 1:
        preaviso_months = 0.5   # 2 semanas
    elif years < 2:
        preaviso_months = 1.0
    else:
        preaviso_months = 2.0
    cesantia_months = min(years, 25)
    preaviso = monthly_salary * preaviso_months
    cesantia = monthly_salary * cesantia_months
    return preaviso + cesantia, [
        ("Preaviso", preaviso), ("Auxilio de cesantía (1 mes/año, tope 25 años)", cesantia),
    ]


def severance_mexico(monthly_salary, years):
    daily = monthly_salary / 30
    indemnizacion_90d = monthly_salary * 3  # 3 meses
    veinte_dias = daily * 20 * years
    prima_antiguedad = daily * 12 * years  # simplificado, sin tope de 2x salario mínimo
    return indemnizacion_90d + veinte_dias + prima_antiguedad, [
        ("Indemnización constitucional (3 meses)", indemnizacion_90d),
        ("20 días por año trabajado", veinte_dias),
        ("Prima de antigüedad (12 días/año)", prima_antiguedad),
    ]


def severance_guatemala(monthly_salary, years):
    indemnizacion = monthly_salary * years
    return indemnizacion, [
        ("Indemnización (1 mes de salario por año)", indemnizacion),
    ]


def severance_el_salvador(monthly_salary, years):
    total = max(monthly_salary * years, monthly_salary * (15 / 30))
    return total, [
        ("Indemnización (30 días de salario por año, mínimo 15 días)", total),
    ]


def severance_nicaragua(monthly_salary, years):
    first_3 = min(years, 3) * monthly_salary
    after_3_years = max(0, years - 3)
    daily = monthly_salary / 30
    after_3 = after_3_years * 20 * daily
    total = min(first_3 + after_3, monthly_salary * 5)
    return total, [
        ("Indemnización por antigüedad (tope de 5 meses)", total),
    ]


def severance_costa_rica(monthly_salary, years):
    # Aproximación de la escala progresiva del Art. 29 (promedio ~21 días/año), tope 8 años.
    daily = monthly_salary / 30
    capped_years = min(years, 8)
    cesantia = daily * 21 * capped_years
    return cesantia, [
        ("Auxilio de cesantía (aprox. 21 días/año, tope 8 años)", cesantia),
    ]


def severance_panama(monthly_salary, years):
    weekly = monthly_salary / 4.3333
    first_10 = min(years, 10) * 3.4 * weekly
    after_10 = max(0, years - 10) * 1 * weekly
    total = first_10 + after_10
    return total, [
        ("Indemnización (3.4 semanas/año, primeros 10 años)", total),
    ]


def severance_peru(monthly_salary, years):
    total = min(monthly_salary * 1.5 * years, monthly_salary * 12)
    return total, [
        ("Indemnización por despido arbitrario (1.5 sueldos/año, tope 12 sueldos)", total),
    ]


def severance_chile(monthly_salary, years):
    capped_years = min(years, 11)
    indemnizacion = monthly_salary * capped_years
    aviso_previo = monthly_salary  # si no se avisa con 30 días de anticipación
    return indemnizacion + aviso_previo, [
        ("Indemnización por años de servicio (tope 11 años)", indemnizacion),
        ("Indemnización sustitutiva de aviso previo (1 mes)", aviso_previo),
    ]


SEVERANCE_CALC = {
    "Honduras": severance_honduras,
    "México": severance_mexico,
    "Guatemala": severance_guatemala,
    "El Salvador": severance_el_salvador,
    "Nicaragua": severance_nicaragua,
    "Costa Rica": severance_costa_rica,
    "Panamá": severance_panama,
    "Perú": severance_peru,
    "Chile": severance_chile,
}

SEVERANCE_HINTS = {
    "Honduras": "Código de Trabajo: preaviso según antigüedad + auxilio de cesantía (1 mes por año, tope 25 años). Solo aplica a despido sin causa justificada.",
    "México": "LFT: indemnización constitucional de 3 meses + 20 días por año + prima de antigüedad (12 días/año). Solo aplica a despido injustificado.",
    "Guatemala": "Código de Trabajo, Art. 82: 1 mes de salario por año de servicio. Solo aplica a despido sin causa justificada.",
    "El Salvador": "Código de Trabajo, Art. 58: 30 días de salario por año, con mínimo de 15 días. Solo aplica a despido injustificado.",
    "Nicaragua": "Código del Trabajo, Art. 45: 1 mes por año los primeros 3 años, 20 días/año después, con tope de 5 meses.",
    "Costa Rica": "Código de Trabajo, Art. 29: escala progresiva de cesantía (aquí aproximada a 21 días/año), con tope de 8 años.",
    "Panamá": "Código de Trabajo, Art. 225: 3.4 semanas por año los primeros 10 años, 1 semana por año adicional después.",
    "Perú": "D.S. 003-97-TR, Art. 38: 1.5 remuneraciones por año de servicio, con tope de 12 remuneraciones (8 años).",
    "Chile": "Código del Trabajo, Art. 163: 1 mes de la última remuneración por año de servicio, con tope de 11 años, más el aviso previo si no se avisó con 30 días de anticipación.",
}


def compute_severance(country, monthly_salary, years):
    calc = SEVERANCE_CALC.get(country)
    if not calc:
        return 0, []
    return calc(monthly_salary, years)


# ---------------------------------------------------------------
# Simulador de inversiones — compara distintos tipos de activo según
# su rango típico de rendimiento anual (educativo, no es una promesa
# de rendimiento real: los mercados varían y el pasado no garantiza
# el futuro).
# ---------------------------------------------------------------
ASSET_TYPES = [
    ("Cuenta de ahorro", 1, 3),
    ("Bonos gubernamentales", 4, 7),
    ("Fondo indexado diversificado", 6, 10),
    ("Acciones individuales", 5, 15),
    ("Bienes raíces (renta)", 5, 9),
]


def compare_investment_scenarios(principal, monthly_contribution, years):
    """Devuelve, por cada tipo de activo, el valor proyectado con la
    tasa más baja y la más alta de su rango típico."""
    results = []
    for name, rate_low, rate_high in ASSET_TYPES:
        total_low, _, _ = compute_interest("compound", principal, monthly_contribution, rate_low, years)
        total_high, _, _ = compute_interest("compound", principal, monthly_contribution, rate_high, years)
        results.append({
            "name": name, "rate_low": rate_low, "rate_high": rate_high,
            "value_low": total_low, "value_high": total_high,
        })
    return results


# ---------------------------------------------------------------
# Simulador de presupuesto del gobierno — el usuario reparte 100%
# de un presupuesto hipotético entre prioridades, y ve si el gasto
# resultante calza con los ingresos (déficit o superávit).
# ---------------------------------------------------------------
GOV_BUDGET_CATEGORIES = [
    ("Educación", 20),
    ("Salud", 18),
    ("Infraestructura", 12),
    ("Seguridad", 10),
    ("Programas sociales", 15),
    ("Servicio de deuda pública", 15),
    ("Otros", 10),
]


def compute_gov_budget(total_revenue, allocations):
    """allocations: lista de (categoria, porcentaje). Devuelve
    (monto_por_categoria, gasto_total, balance)."""
    amounts = [(name, total_revenue * pct / 100) for name, pct in allocations]
    total_spent = sum(a for _, a in amounts)
    balance = total_revenue - total_spent
    return amounts, total_spent, balance



# ---------------------------------------------------------------
# Prueba al final de cada curso — generada automáticamente a partir
# del propio contenido del curso (título = pregunta, texto = respuesta),
# con distractores tomados de otras tarjetas.
# ---------------------------------------------------------------
import random as _random


def _first_sentence(text):
    for sep in [". ", "? ", "! "]:
        if sep in text:
            return text.split(sep)[0] + sep.strip()
    return text


def generate_quiz(cards, other_cards=None, num_questions=4, seed=None):
    """
    cards: tarjetas del curso actual (lista de {title, text, ...}).
    other_cards: tarjetas de otros cursos de la misma categoría, para
    sacar distractores si el curso no tiene suficientes tarjetas propias.
    """
    rng = _random.Random(seed)
    pool = list(cards)
    extra = list(other_cards or [])
    n = min(num_questions, len(cards))
    chosen = rng.sample(cards, n)

    questions = []
    for card in chosen:
        correct = _first_sentence(card["text"])
        distractor_pool = [c for c in pool if c is not card] + extra
        distractor_pool = [c for c in distractor_pool if _first_sentence(c["text"]) != correct]
        rng.shuffle(distractor_pool)
        distractors = []
        seen_texts = {correct}
        for c in distractor_pool:
            t = _first_sentence(c["text"])
            if t not in seen_texts:
                distractors.append(t)
                seen_texts.add(t)
            if len(distractors) == 3:
                break
        options = distractors + [correct]
        rng.shuffle(options)
        questions.append({
            "question": f"¿Cuál de estas frases describe mejor \u201c{card['title']}\u201d?",
            "options": options,
            "correct_index": options.index(correct),
        })
    return questions


# ---------------------------------------------------------------
# Reporte financiero en HTML — se abre en el navegador, y desde ahí
# se puede "Imprimir → Guardar como PDF" sin necesitar instalar
# ninguna librería de PDF.
# ---------------------------------------------------------------
def generate_html_report(user, data):
    import datetime
    import html as html_module

    def esc(s):
        return html_module.escape(str(s))

    country = user["country"]
    fmt = lambda v: format_money(v, country)

    salary_info = data.get("salary_info")
    expenses = data.get("expenses", [])
    debts = data.get("debts", [])
    goals = data.get("goals", [])
    assets = data.get("assets", [])
    liabilities = data.get("liabilities", [])

    total_expenses = sum(e["amount"] for e in expenses)
    net_income = salary_info["net"] if salary_info else 0
    balance = net_income - total_expenses

    by_cat = {}
    for e in expenses:
        by_cat[e["category"]] = by_cat.get(e["category"], 0) + e["amount"]

    total_debt = sum(d["amount"] for d in debts)
    total_assets = sum(a["amount"] for a in assets)
    total_liabilities = sum(l["amount"] for l in liabilities)
    net_worth = total_assets - total_liabilities

    def table_rows(items, cols):
        if not items:
            return '<tr><td colspan="99" class="empty">Sin registros.</td></tr>'
        rows = []
        for item in items:
            cells = "".join(f"<td>{esc(item.get(c, ''))}</td>" for c in cols)
            rows.append(f"<tr>{cells}</tr>")
        return "".join(rows)

    expense_summary_rows = "".join(
        f"<tr><td>{esc(cat)}</td><td>{esc(fmt(amt))}</td></tr>" for cat, amt in sorted(by_cat.items(), key=lambda kv: -kv[1])
    ) or '<tr><td colspan="2" class="empty">Sin gastos registrados.</td></tr>'

    expense_detail_rows = "".join(
        f"<tr><td>{esc(e['name'])}</td><td>{esc(e.get('category', ''))}</td><td>{esc(fmt(e['amount']))}</td></tr>"
        for e in sorted(expenses, key=lambda e: -e["amount"])
    ) or '<tr><td colspan="3" class="empty">Sin gastos registrados.</td></tr>'

    debt_rows = "".join(
        f"<tr><td>{esc(d['name'])}</td><td>{esc(fmt(d['amount']))}</td><td>{esc(fmt(d['payment']))}/mes</td></tr>"
        for d in debts
    ) or '<tr><td colspan="3" class="empty">Sin deudas registradas.</td></tr>'

    goal_rows = "".join(
        f"<tr><td>{esc(g['name'])}</td><td>{esc(fmt(g['saved']))}</td><td>{esc(fmt(g['target']))}</td>"
        f"<td>{round(g['saved'] / g['target'] * 100) if g['target'] else 0}%</td></tr>"
        for g in goals
    ) or '<tr><td colspan="4" class="empty">Sin metas de ahorro.</td></tr>'

    today = datetime.date.today().strftime("%d/%m/%Y")

    return f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reporte financiero — {esc(user['name'])}</title>
<style>
  body {{ font-family: 'Segoe UI', Arial, sans-serif; color: #0F2A1C; max-width: 720px; margin: 40px auto; padding: 0 20px; }}
  h1 {{ color: #1B7A4D; margin-bottom: 4px; }}
  .subtitle {{ color: #4E6459; margin-top: 0; }}
  h2 {{ color: #0F5C39; border-bottom: 2px solid #E3F6EA; padding-bottom: 6px; margin-top: 32px; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
  th, td {{ text-align: left; padding: 8px 10px; border-bottom: 1px solid #DCEFE3; font-size: 14px; }}
  th {{ background: #E3F6EA; color: #0F5C39; }}
  .empty {{ color: #7C9186; font-style: italic; }}
  .balance {{ font-size: 22px; font-weight: bold; }}
  .positive {{ color: #1B7A4D; }}
  .negative {{ color: #C1453A; }}
  .summary-box {{ background: #E3F6EA; border-radius: 10px; padding: 16px 20px; margin-top: 16px; }}
  .footer {{ margin-top: 40px; font-size: 12px; color: #7C9186; }}
  @media print {{ body {{ margin: 0; }} }}
</style>
</head>
<body>
  <h1>🌱 Reporte financiero</h1>
  <p class="subtitle">{esc(user['name'])} · {esc(country)} · generado el {today}</p>

  <div class="summary-box">
    <div>Ingreso neto mensual: {esc(fmt(net_income))}</div>
    <div>Gastos totales: {esc(fmt(total_expenses))}</div>
    <div class="balance {'positive' if balance >= 0 else 'negative'}">Balance: {esc(fmt(balance))}</div>
  </div>

  <h2>Gastos por categoría</h2>
  <table><tr><th>Categoría</th><th>Monto</th></tr>{expense_summary_rows}</table>

  <h2>Detalle de gastos</h2>
  <table><tr><th>Nombre</th><th>Categoría</th><th>Monto</th></tr>{expense_detail_rows}</table>

  <h2>Deudas</h2>
  <table><tr><th>Nombre</th><th>Monto total</th><th>Pago mensual</th></tr>{debt_rows}</table>

  <h2>Metas de ahorro</h2>
  <table><tr><th>Nombre</th><th>Ahorrado</th><th>Meta</th><th>Progreso</th></tr>{goal_rows}</table>

  <h2>Patrimonio neto</h2>
  <div class="summary-box">
    <div>Activos: {esc(fmt(total_assets))}</div>
    <div>Pasivos: {esc(fmt(total_liabilities))}</div>
    <div class="balance {'positive' if net_worth >= 0 else 'negative'}">Patrimonio neto: {esc(fmt(net_worth))}</div>
  </div>

  <p class="footer">
    Generado por la app de Educación Financiera. Para guardarlo como PDF, usa
    "Imprimir" desde tu navegador (Ctrl+P o Cmd+P) y elige "Guardar como PDF".
  </p>
</body>
</html>
"""

# ---------------------------------------------------------------
# Filtrar y buscar gastos — por nombre, categoría y rango de fechas.
# ---------------------------------------------------------------
def filter_expenses(expenses, search="", category="Todas", date_from="", date_to=""):
    search = search.strip().lower()
    result = []
    for e in expenses:
        if search and search not in e["name"].lower():
            continue
        if category and category != "Todas" and e.get("category") != category:
            continue
        e_date = e.get("date", "")
        if date_from and e_date and e_date < date_from:
            continue
        if date_to and e_date and e_date > date_to:
            continue
        result.append(e)
    return result


def expense_categories(expenses):
    """Categorías únicas presentes, ordenadas alfabéticamente, con 'Todas' primero."""
    cats = sorted({e.get("category", "Otros") for e in expenses})
    return ["Todas"] + cats

# ---------------------------------------------------------------
# Historial mensual — cuánto se gastó cada mes, para la gráfica de
# tendencia del Dashboard.
# ---------------------------------------------------------------
_MONTH_ABBR = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]


def monthly_expense_history(expenses):
    """Devuelve una lista de (etiqueta, total) por mes, en orden
    cronológico (más antiguo primero), a partir de la fecha de cada
    gasto. Los gastos sin fecha se ignoran."""
    totals = {}
    for e in expenses:
        date_str = e.get("date", "")
        if not date_str or len(date_str) < 7:
            continue
        month_key = date_str[:7]  # "YYYY-MM"
        totals[month_key] = totals.get(month_key, 0) + e["amount"]

    result = []
    for month_key in sorted(totals.keys()):
        year, month = month_key.split("-")
        label = f"{_MONTH_ABBR[int(month) - 1]} {year}"
        result.append((label, totals[month_key]))
    return result

# ---------------------------------------------------------------
# Historial mensual de gastos — para la gráfica de tendencia del Dashboard.
# ---------------------------------------------------------------
MONTH_ABBR = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
              "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]


def monthly_expense_history(expenses, max_months=6):
    """Agrupa los gastos por mes (a partir de su fecha 'YYYY-MM-DD') y
    devuelve una lista de (etiqueta, total) en orden cronológico, con
    como máximo los últimos max_months meses que tengan datos."""
    totals = {}
    for e in expenses:
        date_str = e.get("date", "")
        if not date_str or len(date_str) < 7:
            continue
        month_key = date_str[:7]  # "YYYY-MM"
        totals[month_key] = totals.get(month_key, 0) + e["amount"]

    ordered_keys = sorted(totals.keys())[-max_months:]
    result = []
    for key in ordered_keys:
        year, month = key.split("-")
        label = f"{MONTH_ABBR[int(month) - 1]} {year[-2:]}"
        result.append((label, totals[key]))
    return result
