"""
app.py — Educación Financiera, versión web hecha en Streamlit (Python puro).

Cómo correrla en tu computadora:
    pip install -r requirements.txt
    streamlit run app.py

Necesitas configurar el secreto DATABASE_URL (ver .streamlit/secrets.toml.example)
con la cadena de conexión de Supabase — la MISMA que ya usa el backend web,
así que las cuentas se comparten entre ambas versiones.
"""
import json
import urllib.request
import urllib.error

import streamlit as st

import logic
import db

st.set_page_config(page_title="Educación Financiera", page_icon="🌱", layout="centered")

# Mismo backend HTTPS ya desplegado en Render — se reutiliza para mandar
# el código de verificación real por correo/SMS.
AUTH_API_BASE = "https://mi-backend-finanzas.onrender.com"


def request_verification_code(method, contact):
    """Pide el código real vía HTTPS. Si el backend no responde, cae a un
    código de prueba local para que la app nunca te deje sin poder entrar."""
    import random
    try:
        req = urllib.request.Request(
            f"{AUTH_API_BASE}/api/send-code",
            data=json.dumps({"contact": contact, "method": method}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if data.get("ok"):
            return {"mode": "real"}
        return {"mode": "demo", "code": str(random.randint(100000, 999999))}
    except Exception:
        return {"mode": "demo", "code": str(random.randint(100000, 999999))}


def check_verification_code(verification, contact, input_code):
    if verification.get("mode") == "demo":
        return input_code == verification.get("code")
    try:
        req = urllib.request.Request(
            f"{AUTH_API_BASE}/api/verify-code",
            data=json.dumps({"contact": contact, "code": input_code}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return bool(data.get("ok"))
    except Exception:
        return False


# ---------------------------------------------------------------
# Estado de la sesión — Streamlit vuelve a correr TODO el script en cada
# clic, así que lo que debe sobrevivir entre esos "reruns" vive aquí.
# ---------------------------------------------------------------
def init_state():
    defaults = {
        "step": "welcome",
        "user": None,
        "pending_user": None,
        "verification": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def go(step):
    st.session_state.step = step
    st.rerun()


def logout():
    st.session_state.user = None
    st.session_state.pending_user = None
    st.session_state.verification = None
    go("welcome")


# ---------------------------------------------------------------
# Pantallas
# ---------------------------------------------------------------
def screen_welcome():
    st.markdown("### 🌱 EDUCACIÓN FINANCIERA")
    st.title("¡Bienvenidos!")
    st.caption("Tu cuenta se guarda cifrada — nunca en texto plano.")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Iniciar sesión", type="primary", use_container_width=True):
            go("signin")
    with col2:
        if st.button("Crear cuenta", use_container_width=True):
            go("create_account")


def screen_signin():
    st.markdown("### 🌱 EDUCACIÓN FINANCIERA")
    st.title("Inicia sesión")
    st.caption("Con el correo o teléfono que usaste al crear tu cuenta.")

    with st.form("signin_form"):
        contact = st.text_input("Correo o teléfono")
        password = st.text_input("Contraseña", type="password")
        submitted = st.form_submit_button("Entrar", type="primary", use_container_width=True)

    if submitted:
        if not contact or not password:
            st.error("Escribe tu correo/teléfono y tu contraseña.")
        else:
            user = db.authenticate(contact, password)
            if not user:
                st.error("Correo/teléfono o contraseña incorrectos.")
            else:
                st.session_state.user = user
                go("home")

    if st.button("← Volver"):
        go("welcome")


def screen_create_account():
    st.markdown("### 🌱 EDUCACIÓN FINANCIERA")
    st.title("Crea tu cuenta")
    st.caption("Cuéntanos quién eres para empezar.")

    with st.form("create_account_form"):
        country = st.selectbox("País", logic.COUNTRIES, index=None, placeholder="Selecciona tu país")
        method = st.radio("¿Cómo quieres recibir tu código?", ["Correo", "Teléfono"], horizontal=True)
        if method == "Correo":
            email = st.text_input("Correo electrónico")
            phone = ""
        else:
            email = ""
            phone = st.text_input("Número de teléfono (con código de país si aplica)")
        name = st.text_input("Nombre")
        password = st.text_input("Crea una contraseña (mínimo 6 caracteres)", type="password")
        password2 = st.text_input("Confirma tu contraseña", type="password")
        submitted = st.form_submit_button("Continuar", type="primary", use_container_width=True)

    if submitted:
        errors = []
        if not country:
            errors.append("Selecciona tu país.")
        if not name.strip():
            errors.append("Escribe tu nombre.")

        method_key = "email" if method == "Correo" else "phone"
        contact = ""
        if method_key == "email":
            if not logic.is_valid_email(email):
                errors.append("Escribe un correo válido.")
            else:
                contact = email.strip()
        else:
            digits = "".join(ch for ch in phone if ch.isdigit())
            if not country or not logic.is_valid_phone(country, digits):
                errors.append("Escribe un número de teléfono real.")
            else:
                info = logic.COUNTRY_PHONE[country]
                contact = f"{info['code']} {digits}"

        if not db.is_strong_enough(password):
            errors.append("La contraseña debe tener al menos 6 caracteres.")
        elif password != password2:
            errors.append("Las contraseñas no coinciden.")

        if not errors and contact and db.contact_exists(contact):
            errors.append("Ya existe una cuenta con ese correo/teléfono. Inicia sesión en vez de crear una nueva.")

        if errors:
            for e in errors:
                st.error(e)
        else:
            st.session_state.pending_user = {
                "name": name.strip(), "country": country, "method": method_key,
                "contact": contact, "password": password,
            }
            st.session_state.verification = request_verification_code(method_key, contact)
            go("verify")

    if st.button("← Volver"):
        go("welcome")


def screen_verify():
    pu = st.session_state.pending_user
    medium = "teléfono" if pu["method"] == "phone" else "correo"

    st.markdown("### 🌱 EDUCACIÓN FINANCIERA")
    st.title(f"Verifica tu {medium}")
    st.caption(f"Enviamos un código a {pu['contact']}.")

    verification = st.session_state.verification
    if verification["mode"] == "real":
        st.success(f"Te enviamos un código real por {'SMS' if medium == 'teléfono' else 'correo'}. Revisa tu {medium}.")
    else:
        st.info(f"Modo de prueba. Tu código es: **{verification['code']}**")

    with st.form("verify_form"):
        code = st.text_input("Código de verificación", max_chars=6)
        submitted = st.form_submit_button("Verificar", type="primary", use_container_width=True)

    if submitted:
        if check_verification_code(verification, pu["contact"], code.strip()):
            user = db.create_user(pu["name"], pu["country"], pu["method"], pu["contact"], pu["password"])
            st.session_state.user = user
            st.session_state.pending_user = None
            st.session_state.verification = None
            go("home")
        else:
            st.error("Código incorrecto. Intenta de nuevo.")

    if st.button("Reenviar código"):
        st.session_state.verification = request_verification_code(pu["method"], pu["contact"])
        st.rerun()


def screen_home():
    user = st.session_state.user
    first_name = user["name"].split(" ")[0]

    top_left, top_right = st.columns([4, 1])
    with top_left:
        st.markdown("### 🌱 EDUCACIÓN FINANCIERA")
    with top_right:
        if st.button("Salir"):
            logout()

    st.title(f"Hola, {first_name}")
    st.caption("¿Qué quieres hacer hoy?")

    st.info(
        "Esta es la primera versión de la app en Streamlit — por ahora solo "
        "incluye cuentas e Inicio. Las demás secciones (Cursos, Calculadora, "
        "Mis finanzas, Recordatorios) se agregan en los próximos pasos."
    )

    st.button("📚 Cursos (próximamente)", use_container_width=True, disabled=True)
    st.button("🧮 Calculadora (próximamente)", use_container_width=True, disabled=True)
    st.button("🐷 Mis finanzas (próximamente)", use_container_width=True, disabled=True)
    st.button("🔔 Recordatorios (próximamente)", use_container_width=True, disabled=True)


# ---------------------------------------------------------------
# Enrutador principal
# ---------------------------------------------------------------
init_state()

SCREENS = {
    "welcome": screen_welcome,
    "signin": screen_signin,
    "create_account": screen_create_account,
    "verify": screen_verify,
    "home": screen_home,
}

SCREENS[st.session_state.step]()
