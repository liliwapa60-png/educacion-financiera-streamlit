# Educación Financiera — versión web en Streamlit (Python)

Esta es una versión alternativa de la app web, hecha completamente en
Python con [Streamlit](https://streamlit.io), en vez de React. Usa la
**misma base de datos de Supabase** que la versión web original — una
cuenta creada en una funciona en la otra, porque comparten los mismos datos.

## ⚠️ Aviso importante sobre las pruebas

No pude correr Streamlit de verdad en el entorno donde armé esto (no tenía
forma de instalarlo ni de conectarme a internet). Lo que sí hice: construí
un simulador de Streamlit y de la base de datos, y con eso probé a fondo
todo el flujo (crear cuenta, verificar código, iniciar sesión, contraseña
incorrecta, contraseña débil, contraseñas que no coinciden, correo
duplicado) — todo pasó. Pero **nunca lo vi correr con el Streamlit real**,
así que es posible que algo pequeño de la interfaz visual no se vea
exactamente como espero. Avísame si algo falla.

## Qué incluye esta primera versión

- Crear cuenta (con verificación real por correo/SMS, usando tu mismo
  backend de Render)
- Iniciar sesión
- Pantalla de Inicio

**Todavía NO incluye** (se agrega en los próximos pasos, avísame cuál
priorizar): Cursos, Calculadora, Mis finanzas, Recordatorios, Dashboard,
modo oscuro, etc. — todo lo que sí tiene la versión de escritorio y la web
en React.

## Cómo correrla en tu computadora

**1.** Instala las dependencias:
```bash
pip install -r requirements.txt
```

**2.** Configura tu conexión a Supabase:
   - Crea una carpeta llamada `.streamlit` (con el punto al inicio) dentro de esta carpeta
   - Copia `secrets.toml.example` ahí adentro, y renómbralo a `secrets.toml`
   - Abre ese archivo y reemplaza la cadena de conexión por la tuya real de Supabase (la misma que usa el backend de Render)

**3.** Corre la app:
```bash
streamlit run app.py
```

Se abre solo en tu navegador, normalmente en `http://localhost:8501`.

## Cómo publicarla gratis (para que cualquiera la use en un link)

**[Streamlit Community Cloud](https://share.streamlit.io)** — gratis, hecho
específicamente para esto:

1. Sube esta carpeta a un repositorio de GitHub (igual que hicimos con el backend)
2. Ve a [share.streamlit.io](https://share.streamlit.io) e inicia sesión con tu cuenta de GitHub
3. Toca "New app", elige tu repositorio y el archivo `app.py`
4. En "Advanced settings" → "Secrets", pega el contenido de tu `secrets.toml` (con tu cadena de conexión real)
5. Despliega — te da un link público en `algo.streamlit.app`

**Importante:** el archivo `secrets.toml` con tu contraseña real nunca debe
subirse a GitHub — solo se pega directo en la configuración de Streamlit
Cloud, en el paso 4.
